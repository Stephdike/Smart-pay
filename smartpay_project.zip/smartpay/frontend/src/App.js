import React, {useState, useEffect} from 'react';
import axios from 'axios';

const API = process.env.REACT_APP_API || 'http://localhost:5000/api';

function App(){
  const [view, setView] = useState('login');
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [user, setUser] = useState(null);

  useEffect(()=> {
    if (token) {
      // fetch simple profile by decoding token on backend in real app; here we store user in login response
    }
  }, [token]);

  if (!token && view === 'login') return <Login onSwitch={()=>setView('register')} onLogin={(t,u)=>{ setToken(t); localStorage.setItem('token', t); setUser(u); }} />;
  if (!token && view === 'register') return <Register onSwitch={()=>setView('login')} onRegister={(t,u)=>{ setToken(t); localStorage.setItem('token', t); setUser(u); }} />;
  return <Dashboard token={token} user={user} onLogout={()=>{ setToken(null); localStorage.removeItem('token'); setUser(null); }} />;
}

function Login({onSwitch, onLogin}){
  const [email,setEmail]=useState(''), [password,setPassword]=useState('');
  const submit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('/api/auth/login', { email, password });
      onLogin(res.data.token, res.data.user);
    } catch (err) { alert(err.response?.data?.error || err.message); }
  };
  return <div style={{padding:20}}>
    <h2>Login</h2>
    <form onSubmit={submit}>
      <input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} required /><br/><br/>
      <input placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} required /><br/><br/>
      <button type="submit">Login</button>
    </form>
    <p onClick={onSwitch} style={{cursor:'pointer'}}>Create an account</p>
  </div>;
}

function Register({onSwitch, onRegister}){
  const [name,setName]=useState(''), [email,setEmail]=useState(''), [password,setPassword]=useState('');
  const submit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('/api/auth/register', { name, email, password });
      onRegister(res.data.token, res.data.user);
    } catch (err) { alert(err.response?.data?.error || err.message); }
  };
  return <div style={{padding:20}}>
    <h2>Register</h2>
    <form onSubmit={submit}>
      <input placeholder="Name" value={name} onChange={e=>setName(e.target.value)} required /><br/><br/>
      <input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} required /><br/><br/>
      <input placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} required /><br/><br/>
      <button type="submit">Register</button>
    </form>
    <p onClick={onSwitch} style={{cursor:'pointer'}}>Have an account? Login</p>
  </div>;
}

function Dashboard({token, user, onLogout}){
  const [me, setMe] = useState(user);
  const [balance, setBalance] = useState(user?.wallet || 0);
  const [toEmail, setToEmail] = useState('');
  const [amount, setAmount] = useState('');
  const [txs, setTxs] = useState([]);

  const authHeaders = { headers: { Authorization: 'Bearer ' + token } };

  const loadTx = async () => {
    try {
      const res = await axios.get('/api/transactions', authHeaders);
      setTxs(res.data);
    } catch (err) { console.error(err); }
  };

  useEffect(()=>{ loadTx(); }, []);

  const topup = async () => {
    try {
      const a = Number(prompt('Enter top-up amount'));
      if (!a || a<=0) return;
      const res = await axios.post('/api/wallet/topup', { amount: a }, authHeaders);
      setBalance(res.data.wallet);
      alert('Top-up successful');
      loadTx();
    } catch (err) { alert(err.response?.data?.error || err.message); }
  };

  const transfer = async () => {
    try {
      const res = await axios.post('/api/wallet/transfer', { toEmail, amount: Number(amount) }, authHeaders);
      setBalance(res.data.wallet);
      setToEmail(''); setAmount('');
      alert('Transfer successful');
      loadTx();
    } catch (err) { alert(err.response?.data?.error || err.message); }
  };

  return <div style={{padding:20}}>
    <h2>SmartPay Dashboard</h2>
    <p>Balance: {balance}</p>
    <button onClick={topup}>Top-up (mock)</button>
    <button onClick={onLogout} style={{marginLeft:10}}>Logout</button>
    <hr/>
    <h3>Send Money</h3>
    <input placeholder="Recipient email" value={toEmail} onChange={e=>setToEmail(e.target.value)} /><br/><br/>
    <input placeholder="Amount" value={amount} onChange={e=>setAmount(e.target.value)} /><br/><br/>
    <button onClick={transfer}>Send</button>
    <hr/>
    <h3>Recent Transactions</h3>
    <ul>
      {txs.map(t=>(
        <li key={t._id}>
          {t.type} - {t.amount} - {t.from?.email} → {t.to?.email} - {new Date(t.createdAt).toLocaleString()}
        </li>
      ))}
    </ul>
  </div>;
}

export default App;
