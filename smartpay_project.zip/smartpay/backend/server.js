const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser:true, useUnifiedTopology:true })
  .then(()=>console.log('MongoDB connected'))
  .catch(err=>console.error(err));

// Models
const UserSchema = new mongoose.Schema({
  name: String,
  email: {type:String, unique:true},
  password: String,
  wallet: { type:Number, default: 0 }
}, { timestamps: true });

const TransactionSchema = new mongoose.Schema({
  from: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  to: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  amount: Number,
  type: String // 'topup' | 'transfer'
}, { timestamps: true });

const User = mongoose.model('User', UserSchema);
const Transaction = mongoose.model('Transaction', TransactionSchema);

// Utils
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const authMiddleware = async (req, res, next) => {
  const token = req.header('Authorization')?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'No token' });
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = await User.findById(decoded.id);
    next();
  } catch (err) {
    res.status(401).json({ error: 'Invalid token' });
  }
};

// Routes
app.post('/api/auth/register', async (req, res) => {
  const { name, email, password } = req.body;
  try {
    if (await User.findOne({ email })) return res.status(400).json({ error: 'Email exists' });
    const hashed = await bcrypt.hash(password, 10);
    const user = await User.create({ name, email, password: hashed });
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET);
    res.json({ token, user: { id: user._id, name: user.name, email: user.email, wallet: user.wallet } });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ error: 'Invalid credentials' });
    const ok = await bcrypt.compare(password, user.password);
    if (!ok) return res.status(400).json({ error: 'Invalid credentials' });
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET);
    res.json({ token, user: { id: user._id, name: user.name, email: user.email, wallet: user.wallet } });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// Top-up (mock) - increases wallet and records transaction
app.post('/api/wallet/topup', authMiddleware, async (req, res) => {
  const { amount } = req.body;
  if (!amount || amount <= 0) return res.status(400).json({ error: 'Invalid amount' });
  try {
    // In production integrate real payment gateway and verify payment
    req.user.wallet += amount;
    await req.user.save();
    await Transaction.create({ from: req.user._id, to: req.user._id, amount, type: 'topup' });
    res.json({ wallet: req.user.wallet });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// Transfer to another user
app.post('/api/wallet/transfer', authMiddleware, async (req, res) => {
  const { toEmail, amount } = req.body;
  if (!toEmail || !amount || amount <= 0) return res.status(400).json({ error: 'Invalid data' });
  try {
    const receiver = await User.findOne({ email: toEmail });
    if (!receiver) return res.status(404).json({ error: 'Receiver not found' });
    if (req.user.wallet < amount) return res.status(400).json({ error: 'Insufficient balance' });
    req.user.wallet -= amount;
    receiver.wallet += amount;
    await req.user.save();
    await receiver.save();
    await Transaction.create({ from: req.user._id, to: receiver._id, amount, type: 'transfer' });
    res.json({ wallet: req.user.wallet });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// Transactions
app.get('/api/transactions', authMiddleware, async (req, res) => {
  const txs = await Transaction.find({ $or: [{ from: req.user._id }, { to: req.user._id }] }).sort({ createdAt: -1 }).limit(100).populate('from to', 'name email');
  res.json(txs);
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, ()=>console.log('Server running on', PORT));
